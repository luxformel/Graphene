/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */  
package Graphene;

import java.util.EventObject;

/**
 *
 * @author luxformel
 */


public class ApplyEvent extends EventObject {
    public ApplyEvent(Object source) {
        super(source);
    }
}